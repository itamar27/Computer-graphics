###
# Students name:
# Sivan Salzmann - 207056334
# Barak Daniel - 204594329
# Itamer Yarden - 204289987
###
from GUI import *

''' Main program '''
if __name__ == '__main__':
    myUI = GUI()
    myUI.presentMessage("Welcome to 3D exercises")
    myUI.createBoard()
