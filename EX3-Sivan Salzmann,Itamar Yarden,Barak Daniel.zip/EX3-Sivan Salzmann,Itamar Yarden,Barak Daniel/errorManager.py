###
# Students name:
# Sivan Salzmann - 207056334
# Barak Daniel - 204594329
# Itamer Yarden - 204289987
###
from tkinter import messagebox

''' This module is responsible for all the errors and thier pop on the UI window '''

def showMsg(msg):
    '''
    Display error message to the main window panel   
    '''
    messagebox.showinfo("Error!", msg)


