# Computer-graphics
Exercise - 3 
Sivan Salzmann - 207056334
Barak Daniel - 204594329
Itamer Yarden - 204289987

To start the program, please run the main.py file.
